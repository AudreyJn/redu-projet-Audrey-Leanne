# -*- coding: utf-8 -*-
"""
Created on Sat Dec 21 15:25:41 2024

@author: audrey jonon
"""
"""
Pour utiliser le code, il faut telécharger tout le 
dossier puis simplement ouvrir et lancer le fichier 
qui se  charge d'ouvrir les donnéees input et de créer 
les données de sorties dans le fichier output (format csv)
puis de créer les figures avec Matplotlib dans le 
fichier images.

"""
